package com.intiformation.GestionAppCommerce.Dao;

import com.intiformation.GestionAppCommerce.Modele.Clients;

/**
 * interface pour la couche CLientDAO qui hérite de IGenericDAO
 * @author giovanni
 *
 */
public interface IClientDAO extends IGenericDAO<Clients>{
	
	

}//END CLASS
