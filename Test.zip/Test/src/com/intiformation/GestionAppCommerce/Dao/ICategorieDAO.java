package com.intiformation.GestionAppCommerce.Dao;

import com.intiformation.GestionAppCommerce.Modele.Categorie;

public interface ICategorieDAO extends IGenericDAO<Categorie>{
	

}
