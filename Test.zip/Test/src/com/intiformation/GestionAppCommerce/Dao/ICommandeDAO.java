package com.intiformation.GestionAppCommerce.Dao;

import com.intiformation.GestionAppCommerce.Modele.Commande;

public interface ICommandeDAO extends IGenericDAO<Commande>{
	
	


}
